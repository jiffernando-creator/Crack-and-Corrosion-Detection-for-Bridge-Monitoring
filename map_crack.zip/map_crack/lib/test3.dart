import 'dart:io';

import 'package:file_selector/file_selector.dart';
import 'package:flutter/material.dart';


class FolderPickerScreen extends StatefulWidget {
  const FolderPickerScreen({super.key});

  @override
  State<FolderPickerScreen> createState() => _FolderPickerScreenState();
}

class _FolderPickerScreenState extends State<FolderPickerScreen> {
  List<FileSystemEntity> files = [];

  Future<void> _pickFolderAndListFiles() async {
    final String? folderPath = await getDirectoryPath();

    if (folderPath != null) {
      final directory = Directory(folderPath);
      final List<FileSystemEntity> fileList = directory.listSync();

      setState(() {
        files = fileList;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Folder Picker')),
      body: Column(
        children: [
          ElevatedButton(
            onPressed: _pickFolderAndListFiles,
            child: const Text('Pick Folder'),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: files.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(files[index].path.split(Platform.pathSeparator).last),
                  subtitle: Text(files[index].path),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}