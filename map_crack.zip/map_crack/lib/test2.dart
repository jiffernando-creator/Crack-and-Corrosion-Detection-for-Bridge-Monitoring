import 'dart:io';
import 'dart:ui';

import 'package:file_selector/file_selector.dart';
import 'package:flutter/material.dart';
import 'package:google_map_windows/google_map_windows.dart';
import 'package:path/path.dart' as p;

class PinData {
  final String title;
  final String description;
  final String imageUrl;
  final LatLng location;

  PinData({
    required this.title,
    required this.description,
    required this.imageUrl,
    required this.location,
  });
}

class Test2 extends StatefulWidget {
  const Test2({super.key});

  @override
  State<Test2> createState() => _Test2State();
}

class _Test2State extends State<Test2> {
  late WindowsMapController mapController;
  int zoom = 17;
  int? hoveredIndex;
  List<Marker> markers = [];
  String user="";
  String title="";


  List<FileSystemEntity> files = [];
  List<PinData> pinDataList = [

  ];
  void clearAllMarkers() {
    for (final marker in markers) {
      mapController.removeMarker(marker);
    }
    markers.clear();
  }
  Future<void> _pickFolderAndListFiles() async {
    final String? folderPath = await getDirectoryPath();


    if (folderPath != null) {
      final directory = Directory(folderPath);
      user=p.basename(directory.parent.path);
      title=p.basename(directory.path);

      final List<FileSystemEntity> fileList = directory.listSync();

      final List<PinData> pins = [];

      for (var file in fileList) {
        if (file is File && file.path.endsWith('.jpg')) {
          final filename = file.uri.pathSegments.last;
          final regex = RegExp(
              r'detected_(crack|corrosion|corrosion_crack|crack_corrosion)_(\d{8}-\d{6})_lat([-\d.]+)_lon([-\d.]+)_alt[\d.]+\.jpg'
          );
          final match = regex.firstMatch(filename);

          if (match != null) {
            final type = match.group(1)!;
            final timestamp = match.group(2)!; // e.g., 20250501-122631
            final lat = double.parse(match.group(3)!);
            final lon = double.parse(match.group(4)!);

            final formattedTime = _formatTimestamp(timestamp);

            pins.add(PinData(
              title: _formatDetectionType(type),
              description: "Detected at $formattedTime",
              imageUrl: file.path,
              location: LatLng(lat: lat,lng: lon),
            ));
          }
        }
      }

      setState(() {
        pinDataList = pins;
      });
      clearAllMarkers();
      for (var pin in pins) {

      final marker = Marker(position: pin.location, title: pin.title, opacity: 0.7);
      mapController.addMarker(marker);
      markers.add(marker);

      }
      if (pins.isNotEmpty) {
        // Calculate bounds
        double minLat = pins.first.location.lat;
        double maxLat = pins.first.location.lat;
        double minLng = pins.first.location.lng;
        double maxLng = pins.first.location.lng;

        for (var pin in pins) {
          if (pin.location.lat < minLat) minLat = pin.location.lat;
          if (pin.location.lat > maxLat) maxLat = pin.location.lat;
          if (pin.location.lng < minLng) minLng = pin.location.lng;
          if (pin.location.lng > maxLng) maxLng = pin.location.lng;
        }

        // Compute center
        double centerLat = (minLat + maxLat) / 2;
        double centerLng = (minLng + maxLng) / 2;

        // Basic zoom level adjustment (optional)
        double latDiff = maxLat - minLat;
        double lngDiff = maxLng - minLng;
        double maxDiff = latDiff > lngDiff ? latDiff : lngDiff;

        int zoom;
        if (maxDiff < 0.001) {
          zoom = 24;
        } else if (maxDiff < 0.01) {
          zoom = 22;
        } else if (maxDiff < 0.05) {
          zoom = 20;
        } else if (maxDiff < 0.1) {
          zoom = 18;
        } else {
          zoom = 16;
        }

        mapController.setZoom(zoom);
        mapController.panTo(LatLng(lat: centerLat, lng: centerLng));
      }

    }
  }

  String _formatDetectionType(String type) {
    return type
        .replaceAll('_', ' ')
        .split(' ')
        .map((word) => word[0].toUpperCase() + word.substring(1))
        .join(' ') + ' Detected';
  }

  void highlightMarker(PinData selectedPin) {
    clearAllMarkers();
    for (var pin in pinDataList) {
      final isSelected = pin == selectedPin;

      final marker = Marker(
        position: pin.location,
        title: pin.title,
        opacity: isSelected ? 1 : 0.7,
      );

      mapController.addMarker(marker);
      markers.add(marker);
    }

    mapController.panTo(selectedPin.location);
  }



  String _formatTimestamp(String raw) {
    final year = raw.substring(0, 4);
    final month = raw.substring(4, 6);
    final day = raw.substring(6, 8);
    final hour = raw.substring(9, 11);
    final minute = raw.substring(11, 13);
    final second = raw.substring(13, 15);
    return "$year-$month-$day $hour:$minute:$second";
  }

  @override
  void initState() {
    super.initState();
    mapController = WindowsMapController();
    mapController.initMap();
    mapController.apiKey = "AIzaSyBogVC8SBZ82kK-skI8OK9y-XhxugQUPkk";

    mapController.onMapInitialed = () {

    };
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            child: Row(
              children: [
                const Text('Crack and Corrosion Mapping', style: TextStyle(fontWeight: FontWeight.bold,fontSize: 24),),
                Spacer(),
                ElevatedButton(
                  onPressed: _pickFolderAndListFiles,
                  child: const Text('Pick Folder'),
                )
              ],
            ),
          ),
          Expanded(child: Stack(
            children: [
              Positioned.fill(
                child: WindowsMap(
                  controller: mapController,
                  zoom: zoom,
                  center: LatLng(lng: 121.0583,lat: 13.7565),
                ),
              ),
              if(pinDataList.isNotEmpty)
              Align(
                alignment: Alignment.topRight,
                child: Card(
                  elevation: 4, // Shadow depth
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16), // Rounded corners
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children:  [
                        Text(
                          "USER: $user",
                        ),
                        SizedBox(height: 8),
                        Text("TITLE: $title"),
                      ],
                    ),
                  ),
                ),
              ),
              if(pinDataList.isNotEmpty)
              Align(
                alignment: Alignment.bottomLeft,
                child: Container(
                  height: 200,
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  color: Colors.white.withOpacity(0.9),
                  child: ScrollConfiguration(
                    behavior: const ScrollBehavior().copyWith(scrollbars: true, dragDevices: {
                      PointerDeviceKind.mouse,
                      PointerDeviceKind.touch,
                    }),
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: pinDataList.length,
                      itemBuilder: (context, index) {
                        final pin = pinDataList[index];
                        return MouseRegion(
                          onEnter: (_) => setState(() => hoveredIndex = index),
                          onExit: (_) => setState(() => hoveredIndex = null),
                          child: Stack(
                            children: [
                              Container(
                                width: 250,
                                margin: const EdgeInsets.symmetric(horizontal: 8),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(12),
                                  color: Colors.white,
                                  boxShadow: [BoxShadow(color: Colors.grey, blurRadius: 5)],
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    ClipRRect(
                                      borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                                      child: Image.file(File(pin.imageUrl), height: 120, width: 250, fit: BoxFit.cover),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Text(pin.title, style: const TextStyle(fontWeight: FontWeight.bold)),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 8),
                                      child: Text(pin.description, maxLines: 2, overflow: TextOverflow.ellipsis),
                                    ),
                                  ],
                                ),
                              ),
                            if (hoveredIndex == index)
                        Positioned.fill(
                          child: ClipRRect(
                            borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                            child: Container(
                              height: 120,
                              width: 250,
                              decoration: BoxDecoration(
                                color: Colors.black.withOpacity(0.2),
                              ),
                              child: BackdropFilter(
                                filter: ImageFilter.blur(sigmaX: 4.0, sigmaY: 4.0),
                                child: Center(
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      IconButton(
                                        icon: Icon(Icons.location_on, color: Colors.white, size: 45),
                                        tooltip: "Highlight on Map",
                                        onPressed: () => highlightMarker(pin),
                                      ),
                                      SizedBox(width: 12),
                                      IconButton(
                                        icon: Icon(Icons.open_in_full, color: Colors.white, size: 45),
                                        tooltip: "View Image",
                                        onPressed: () => showDialog(
                                          context: context,
                                          builder: (_) => Dialog(
                                            child: Image.file(File(pin.imageUrl)),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                            ],
                          ),
                        );
                      },
                    ),
                  ),
                ),
              ),
            ],
          ))
        ],
      ),
    );
  }
}
