from PyQt5.QtCore import pyqtSignal, QThread
import socket
import threading
import json

class TelemetryThread(QThread):
    telemetry_signal = pyqtSignal(str)

    def run(self):
        def handle_telemetry_connection(conn):
            with conn:
                while True:
                    try:
                        data = conn.recv(1024)
                        if not data:
                            print("[Telemetry] Connection closed")
                            break
                        decoded = data.decode().strip()
                        telemetry_data = json.loads(decoded)
                        display_text = (f"Lat: {telemetry_data['lat']:.6f}, "
                                        f"Lon: {telemetry_data['lon']:.6f}, "
                                        f"Alt: {telemetry_data['alt']:.2f} m, "
                                        f"Heading: {telemetry_data['heading']:.2f}°")
                        self.telemetry_signal.emit(display_text)
                    except Exception as e:
                        print("[Telemetry] Error:", e)
                        break

        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server.bind(('0.0.0.0', 5050))
        server.listen(1)
        print("[Telemetry] Server started on port 5050")

        while True:
            conn, addr = server.accept()
            print(f"[Telemetry] Connected by {addr}")
            threading.Thread(target=handle_telemetry_connection, args=(conn,), daemon=True).start()
