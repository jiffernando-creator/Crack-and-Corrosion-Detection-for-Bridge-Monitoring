import cv2
import subprocess
import numpy as np
from PyQt5.QtGui import QImage, QPixmap
from PyQt5.QtCore import QThread, pyqtSignal
import time
import os
from ultralytics import YOLO
from math import radians, cos, sin, asin, sqrt
import torch
from super_gradients.training import models

class VideoThread(QThread):
    change_pixmap_signal = pyqtSignal(np.ndarray)

    def __init__(self, rtmp_url, width=1280, height=720):
        super().__init__()
        self._run_flag = True
        self.rtmp_url = rtmp_url
        self.width = width
        self.height = height
        self.model = None
        self.telemetry_data = {"lat": 0.0, "lon": 0.0, "alt": 0.0}
        self.saved_locations = []
        self.user_name = "UnknownUser"
        self.bridge_name = "UnknownBridge"
        self.bridge_address = "UnknownAddress"

    def update_bridge_info(self, user_name, bridge_name, bridge_address):
        self.user_name = user_name
        self.bridge_name = bridge_name
        self.bridge_address = bridge_address


    def update_telemetry(self, lat, lon, alt):
        self.telemetry_data = {"lat": lat, "lon": lon, "alt": alt}

    def load_model(self, model_type):
        """Load the selected model when called."""
        if model_type == "YOLOv8":
            # self.model = YOLO("yolov8n.pt").to('cuda')
            self.model = YOLO("runs/train2/bridge_damage/weights/best.pt").to('cuda')
        elif model_type == "YOLO-NAS":
            self.model = models.get(
                'yolo_nas_s',   # or 'yolo_nas_m', 'yolo_nas_l' if you trained different
                num_classes=5,
                checkpoint_path='yolo-nas.pth'  # your trained model
            )
            self.model = self.model.to('cuda')
        elif model_type == "EfficientDet":
            self.model = YOLO("yolov8n.pt").to('cuda')
    
    def haversine_distance(self, lat1, lon1, alt1, lat2, lon2, alt2):
        """Calculate 3D distance between two GPS+Altitude points in meters."""
        from math import radians, cos, sin, asin, sqrt

        # Radius of Earth (mean radius) in meters
        R = 6371000  

        # Haversine formula for lat/lon distance
        d_lat = radians(lat2 - lat1)
        d_lon = radians(lon2 - lon1)
        a = sin(d_lat / 2)**2 + cos(radians(lat1)) * cos(radians(lat2)) * sin(d_lon / 2)**2
        c = 2 * asin(sqrt(a))
        horizontal_distance = R * c  # meters

        # Altitude difference
        d_alt = alt2 - alt1  # meters

        # 3D distance
        distance_3d = sqrt(horizontal_distance**2 + d_alt**2)

        return distance_3d


    def run(self):
        while self._run_flag:
            print("[VideoThread] Attempting to connect to RTMP stream...")

            ffmpeg_cmd = [
                "ffmpeg",
                "-fflags", "nobuffer",
                "-flags", "low_delay",
                "-analyzeduration", "0",
                "-i", self.rtmp_url,
                "-f", "image2pipe",
                "-pix_fmt", "bgr24",
                "-vcodec", "rawvideo",
                "-"
            ]

            try:
                pipe = subprocess.Popen(
                    ffmpeg_cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.DEVNULL,
                    bufsize=10**8
                )

                while self._run_flag:
                    for _ in range(5):
                        if pipe.stdout.peek(1):
                            pipe.stdout.read(self.width * self.height * 3)

                    raw_image = pipe.stdout.read(self.width * self.height * 3)
                    if not raw_image:
                        break

                    frame = np.frombuffer(raw_image, dtype=np.uint8).reshape((self.height, self.width, 3))

                    if self.model is not None:
                        small_frame = cv2.resize(frame, (640, 360))
                        if isinstance(self.model, YOLO):  # ultralytics YOLOv8
                            results = self.model(small_frame, verbose=False)
                            names = results[0].names
                            detected_boxes = results[0].boxes
                            detected_classes = detected_boxes.cls.cpu().numpy()
                            detected_xyxy = detected_boxes.xyxy.cpu().numpy()

                        else:  # SuperGradients YOLO-NAS
                            preds = self.model.predict(small_frame, conf=0.25)._images_prediction_lst[0]
                            names = preds.class_names
                            detected_boxes = preds.prediction

                            detected_classes = detected_boxes.labels.astype(int)
                            detected_xyxy = detected_boxes.bboxes_xyxy

                       
                        save_frame = False

                        filtered_boxes = []
                        filtered_classes = []

                        for box, cls_id in zip(detected_xyxy, detected_classes):
                            label = names[int(cls_id)]
                            if label.lower() in ["rust", "corrosion", "crack"]:
                                save_frame = True
                                filtered_boxes.append(box)
                                filtered_classes.append(label)

                        annotated_frame = small_frame.copy()

                        for box, label in zip(filtered_boxes, filtered_classes):
                            x1, y1, x2, y2 = map(int, box)
                            cv2.rectangle(annotated_frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                            cv2.putText(annotated_frame, label, (x1, y1 - 10),
                                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

                        if save_frame:
                            lat = self.telemetry_data.get("lat", 0.0)
                            lon = self.telemetry_data.get("lon", 0.0)
                            alt = self.telemetry_data.get("alt", 0.0)

                            too_close = False
                            for saved_lat, saved_lon, saved_alt in self.saved_locations:
                                distance = self.haversine_distance(lat, lon, alt, saved_lat, saved_lon, saved_alt)
                                if distance <= 1.0:  # 1 meter
                                    too_close = True
                                    print(f"[VideoThread] Skipping save: too close ({distance:.2f} m) to previous detection.")
                                    break

                            if not too_close:
                                timestamp = time.strftime("%Y%m%d-%H%M%S")
                                bridge_folder_name = f"{self.bridge_name}_{self.bridge_address}".replace(" ", "_")
                                save_dir = os.path.join(self.user_name, bridge_folder_name)
                                os.makedirs(save_dir, exist_ok=True)

                                filename = f"detected_rust_{timestamp}_lat{lat:.6f}_lon{lon:.6f}_alt{alt:.2f}.jpg"
                                filepath = os.path.join(save_dir, filename)

                                # Save annotated_frame instead of raw frame
                                cv2.imwrite(filepath, annotated_frame)
                                print(f"[VideoThread] Saved detection at {filepath}")

                                self.saved_locations.append((lat, lon, alt))

                        # Upscale annotated_frame to match display size if needed
                        annotated_frame = cv2.resize(annotated_frame, (self.width, self.height))
                        self.change_pixmap_signal.emit(annotated_frame)

                    else:
                        self.change_pixmap_signal.emit(frame)

                pipe.terminate()
                print("[VideoThread] Stream ended or error, retrying in 2 seconds...")
                time.sleep(2)

            except Exception as e:
                print(f"[VideoThread] Error: {e}, retrying in 2 seconds...")
                time.sleep(2)


    def stop(self):
        self._run_flag = False
        self.wait()
