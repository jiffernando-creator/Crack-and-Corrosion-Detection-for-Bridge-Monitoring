import sys
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QDialog, QPushButton,
    QVBoxLayout, QFormLayout, QLineEdit, QDialogButtonBox,
    QLabel, QComboBox
)
from PyQt5.QtGui import QImage, QPixmap
import cv2

from PyQt5 import uic
from video_class import VideoThread
from telemetry_class import TelemetryThread

class ModelSelectDialog(QDialog):
    def __init__(self, parent=None):
        super(ModelSelectDialog, self).__init__(parent)
        self.setWindowTitle("Select Detection Model")

        self.modelComboBox = QComboBox()
        self.modelComboBox.addItems(["YOLOv8", "YOLO-NAS", "EfficientDet"])

        self.buttonBox = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        self.buttonBox.accepted.connect(self.accept)
        self.buttonBox.rejected.connect(self.reject)

        layout = QVBoxLayout()
        layout.addWidget(QLabel("Choose a model:"))
        layout.addWidget(self.modelComboBox)
        layout.addWidget(self.buttonBox)
        self.setLayout(layout)

    def selected_model(self):
        return self.modelComboBox.currentText()

class EditDialog(QDialog):
    def __init__(self, parent=None):
        super(EditDialog, self).__init__(parent)
        self.setWindowTitle("Edit Bridge Details")

        self.bridgeNameInput = QLineEdit()
        self.addressInput = QLineEdit()
        self.userInput = QLineEdit()

        form_layout = QFormLayout()
        form_layout.addRow("Bridge Name:", self.bridgeNameInput)
        form_layout.addRow("Address:", self.addressInput)
        form_layout.addRow("User:", self.userInput)

        self.buttonBox = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        self.buttonBox.accepted.connect(self.accept)  # Save
        self.buttonBox.rejected.connect(self.reject)  # Cancel

        layout = QVBoxLayout()
        layout.addLayout(form_layout)
        layout.addWidget(self.buttonBox)

        self.setLayout(layout)

    def closeEvent(self, event):
        self.video_thread.stop()
        event.accept()

    
class MainApp(QMainWindow):
    def __init__(self):
        super(MainApp, self).__init__()
        uic.loadUi("main.ui", self)

        self.video_thread = VideoThread("rtmp://192.168.85.202:1935/live/stream")
        self.video_thread.change_pixmap_signal.connect(self.update_image)
        self.video_thread.start()

        self.telemetry_thread = TelemetryThread()
        self.telemetry_thread.telemetry_signal.connect(self.update_telemetry_data)
        self.telemetry_thread.start()

        # Connect editPB to open dialog
        if hasattr(self, 'editPB'):
            self.editPB.clicked.connect(self.show_edit_dialog)

        if hasattr(self, 'startPB'):
            self.startPB.clicked.connect(self.start_detection)
            self.startPB.setEnabled(False)

    def show_edit_dialog(self):
        dialog = EditDialog(self)
        if dialog.exec_():
            bridge_name = dialog.bridgeNameInput.text()
            address = dialog.addressInput.text()
            user = dialog.userInput.text()

            # Update labels in the main window
            if hasattr(self, 'name_lb'):
                self.name_lb.setText('Bridge: '+bridge_name)
            if hasattr(self, 'address_lb'):
                self.address_lb.setText('Address: '+address)
            if hasattr(self, 'user_lb'):
                self.user_lb.setText('User: '+user)

            # 💥 Pass user and bridge info to video_thread
            self.video_thread.update_bridge_info(user, bridge_name, address)
            if bridge_name and address and user:
                self.startPB.setEnabled(True)
            else:
                self.startPB.setEnabled(False)

    
    def update_image(self, cv_img):
        """Updates the image_label with a new opencv image"""
        qt_img = self.convert_cv_qt(cv_img)
        if hasattr(self, 'labelVideo'):
            self.labelVideo.setPixmap(qt_img)
    
    def start_detection(self):
        if self.video_thread.model is None:
            # No model loaded yet → Show selection dialog
            dialog = ModelSelectDialog(self)
            if dialog.exec_():
                selected_model = dialog.selected_model()
                print(f"[MainApp] Loading model: {selected_model}")
                self.video_thread.load_model(selected_model)
                self.startPB.setText("Stop")
        else:
            # Model is already loaded → Unload model
            print("[MainApp] Stopping detection and unloading model.")
            self.video_thread.model = None
            self.startPB.setText("Start")

    def convert_cv_qt(self, cv_img):
        """Convert from an opencv image to QPixmap"""
        rgb_image = cv2.cvtColor(cv_img, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb_image.shape
        bytes_per_line = ch * w
        convert_to_Qt_format = QImage(rgb_image.data, w, h, bytes_per_line, QImage.Format_RGB888)
        p = convert_to_Qt_format.scaled(self.labelVideo.width(), self.labelVideo.height())
        return QPixmap.fromImage(p)
    
    def update_telemetry_data(self, text):
        if hasattr(self, 'dataLabel'):
            self.dataLabel.setText(text)
        try:
            # Assuming telemetry text is like "Lat: 14.5995,Lon: 120.9842,Alt: 15.25"
            data_parts = text.split(",")
            lat = float(data_parts[0].split(":")[1].strip())
            lon = float(data_parts[1].split(":")[1].strip())
            alt_text = data_parts[2].split(":")[1].strip()

            # Remove 'm' if it exists
            if alt_text.endswith('m'):
                alt_text = alt_text[:-1].strip()
            
            alt = float(alt_text)
                
            self.video_thread.update_telemetry(lat, lon, alt)
        except Exception as e:
            print(f"[MainApp] Telemetry parse error: {e}")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainApp()
    window.show()
    sys.exit(app.exec_())
